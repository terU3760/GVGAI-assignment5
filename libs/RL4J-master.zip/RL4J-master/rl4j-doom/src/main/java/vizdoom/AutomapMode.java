package vizdoom;
public enum AutomapMode{
    NORMAL,
    WHOLE,
    OBJECTS,
    OBJECTS_WITH_SIZE;
}
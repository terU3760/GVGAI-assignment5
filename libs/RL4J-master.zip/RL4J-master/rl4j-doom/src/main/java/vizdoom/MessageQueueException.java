package vizdoom;
public class MessageQueueException extends java.lang.RuntimeException {
    public MessageQueueException(String message) {
        super(message);
    }
}

package vizdoom;
public class ViZDoomErrorException extends java.lang.RuntimeException {
    public ViZDoomErrorException(String message) {
        super(message);
    }
}

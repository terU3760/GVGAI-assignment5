package vizdoom;
public class FileDoesNotExistException extends java.lang.RuntimeException {
    public FileDoesNotExistException(String message) {
        super(message);
    }
}

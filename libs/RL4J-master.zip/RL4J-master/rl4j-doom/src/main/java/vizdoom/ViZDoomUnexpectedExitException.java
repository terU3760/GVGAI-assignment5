package vizdoom;
public class ViZDoomUnexpectedExitException extends java.lang.RuntimeException {
    public ViZDoomUnexpectedExitException(String message) {
        super(message);
    }
}

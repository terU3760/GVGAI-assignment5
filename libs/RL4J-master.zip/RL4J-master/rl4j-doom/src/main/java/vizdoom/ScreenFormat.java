package vizdoom;
public enum ScreenFormat {
    CRCGCB,
    RGB24,
    RGBA32,
    ARGB32,
    CBCGCR,
    BGR24,
    BGRA32,
    ABGR32,
    GRAY8,
    DOOM_256_COLORS8;
}

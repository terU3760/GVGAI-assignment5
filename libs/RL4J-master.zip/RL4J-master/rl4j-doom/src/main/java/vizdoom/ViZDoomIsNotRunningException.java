package vizdoom;
public class ViZDoomIsNotRunningException extends java.lang.RuntimeException {
    public ViZDoomIsNotRunningException(String message) {
        super(message);
    }
}

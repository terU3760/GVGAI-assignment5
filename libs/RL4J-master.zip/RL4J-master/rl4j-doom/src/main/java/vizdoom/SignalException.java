package vizdoom;
public class SignalException extends java.lang.RuntimeException {
    public SignalException(String message) {
        super(message);
    }
}

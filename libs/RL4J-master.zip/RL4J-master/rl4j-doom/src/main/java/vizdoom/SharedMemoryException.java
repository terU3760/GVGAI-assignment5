package vizdoom;
public class SharedMemoryException extends java.lang.RuntimeException {
    public SharedMemoryException(String message) {
        super(message);
    }
}
